<div class="card-footer d-flex justify-content-end py-6 px-0">
    <a href="{{ route('person.index') }}" class="btn btn-light-danger btn-active-danger me-2">
        <i class="ki-duotone ki-cross-circle">
            <span class="path1"></span>
            <span class="path2"></span>
        </i>
        Cancelar
    </a>

    <button type="submit" class="btn btn-light-primary" id="kt_account_profile_details_submit">
        <i class="ki-duotone ki-send">
            <span class="path1"></span>
            <span class="path2"></span>
        </i>
        Savar Registro
    </button>

</div>
